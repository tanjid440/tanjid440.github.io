public class BinarySearch {
    public static void main (String[] args) {
        
        int[] array={1,2,3,4,5,6,7,8,9};
        int min_index=0;
        int max_index=array.length-1;
        int mid_index=0;
        int query=4;
        boolean is_found=false;
        
        while (min_index<=max_index) {
            mid_index=(min_index+max_index)/2;
            if (array[mid_index]==query) {
                is_found=true;
                break;
            } else if (array[mid_index]<query) {
                min_index=mid_index+1;
            } else if (array[mid_index]>query) {
                max_index=mid_index-1;
            }
        }
        
        if (is_found) {
            System.out.println(query+" found at index "+mid_index);
        } else {
            System.out.println(query+" not found in the array");
        }
        
    }
}

