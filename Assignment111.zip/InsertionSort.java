public class InsertionSort {
    public static void main (String[] args) {
        
        int[] array={9,8,7,6,5,4,3,2,1};
        
        for (int i=0;i<array.length;i++) {
            int tmp=array[i];
            int j=i-1;
            for (;j>=0 && array[j]>tmp;j--) {
                array[j+1]=array[j];
            }
            array[j+1]=tmp;
        }
        
        for (int i=0;i<array.length;i++) {
            System.out.print(array[i]+" ");
        }
        
    }
}

